// Script to verify that Python is installed and accessible on the system.
const { spawnSync } = require('child_process');

function checkPython() {
  const candidate = process.platform === 'win32' ? 'python' : 'python3';
  const result = spawnSync(candidate, ['--version'], { encoding: 'utf8' });
  if (result.error) {
    console.error('[check-python] Python not found:', result.error);
    process.exit(1);
  }
  console.log(`[check-python] Found ${candidate}: ${result.stdout.trim() || result.stderr.trim()}`);
}

checkPython();