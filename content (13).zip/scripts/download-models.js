// Placeholder script for downloading AI models.
// In a production environment this file would fetch model
// binaries (e.g. .pth or .onnx files) from a server and store them
// into the `models-data` directory. For development purposes it
// simply logs the download request and resolves immediately.

const fs = require('fs');
const path = require('path');

/**
 * Download a model by name. Accepts a callback to report progress.
 * Returns a promise that resolves when download completes.
 *
 * @param {string} modelName - The name of the model to download
 * @param {function} onProgress - Callback invoked with progress (0–100)
 */
async function downloadModel(modelName, onProgress) {
  console.log(`[download-models] Requested download for model: ${modelName}`);
  // Simulate progress updates
  for (let i = 0; i <= 100; i += 20) {
    await new Promise((res) => setTimeout(res, 100));
    onProgress(i);
  }
  // Create a dummy file in models-data to simulate the model
  const modelsDir = path.join(__dirname, '..', 'models-data');
  if (!fs.existsSync(modelsDir)) {
    fs.mkdirSync(modelsDir);
  }
  const modelPath = path.join(modelsDir, `${modelName}.bin`);
  fs.writeFileSync(modelPath, Buffer.alloc(1024));
  console.log(`[download-models] Model ${modelName} downloaded to ${modelPath}`);
  return { success: true, path: modelPath };
}

module.exports = { downloadModel };