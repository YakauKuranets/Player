"""PLAYE PhotoLab backend package initialization."""

# This package contains FastAPI application modules for the cloud backend.