"""Task queue package for PLAYE PhotoLab backend.

This package will house Celery tasks and workers used to perform AI
computations asynchronously.
"""