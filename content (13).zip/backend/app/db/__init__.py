"""Database package for PLAYE PhotoLab backend.

This package will handle database models and connections using SQLAlchemy.
"""