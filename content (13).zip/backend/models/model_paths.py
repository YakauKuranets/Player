"""
Helper utilities for resolving model file locations.

This module provides functions for determining where AI model weight
files are stored on disk. By default, models are expected to live in
the ``models-data`` directory at the project root. You can override
this location by setting the environment variable ``PLAYE_MODELS_DIR``
to a custom path. The functions here resolve to ``pathlib.Path``
objects for convenience.

Usage::

    from models.model_paths import get_models_dir
    weights_dir = get_models_dir()
    restoreformer_path = weights_dir / 'restoreformer.pth'
"""

from __future__ import annotations

import os
from pathlib import Path


def get_models_dir() -> Path:
    """Return the directory where model weights are stored.

    If the environment variable ``PLAYE_MODELS_DIR`` is set it will be
    used as the model directory. Otherwise, the path will default to the
    ``models-data`` directory located two levels up from this file
    (i.e. at the project root). The returned object is a ``Path``
    instance which may or may not exist on disk.

    Returns:
        pathlib.Path: Path to the directory containing model weight
        files.
    """
    env_dir = os.getenv("PLAYE_MODELS_DIR")
    if env_dir:
        return Path(env_dir)
    # Default fallback: ../../models-data relative to this file
    return Path(__file__).resolve().parents[2] / "models-data"