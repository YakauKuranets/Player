// Main process for PLAYE PhotoLab desktop
// This file bootstraps the Electron application and manages the lifecycle of
// the embedded Python backend. It is adapted from the development
// instructions provided in Инструкция_Desktop_AI.md.

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
// Use node-fetch for making HTTP requests from the main process.
const fetch = require('node-fetch');

let mainWindow;
let pythonProcess;

// Determine paths based on dev/prod mode.
const isDev = process.argv.includes('--dev');
const backendPath = isDev
  ? path.join(__dirname, 'backend')
  : path.join(process.resourcesPath, 'backend');

/**
 * Spawn the Python backend using the appropriate interpreter. Resolves
 * when the backend prints the Uvicorn startup message. Rejects on
 * failure or after a timeout.
 */
function startPythonBackend() {
  return new Promise((resolve, reject) => {
    console.log('[Main] Starting Python backend...');

    const pythonExecutable = process.platform === 'win32' ? 'python' : 'python3';
    const serverScript = path.join(backendPath, 'server.py');

    pythonProcess = spawn(pythonExecutable, [serverScript], {
      cwd: backendPath,
      env: { ...process.env, PYTHONUNBUFFERED: '1' }
    });

    pythonProcess.stdout.on('data', (data) => {
      const message = data.toString();
      console.log(`[Python] ${message}`);
      // When Uvicorn announces startup, resolve the promise.
      if (message.includes('Uvicorn running')) {
        console.log('[Main] Python backend started successfully');
        resolve();
      }
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error(`[Python Error] ${data}`);
    });

    pythonProcess.on('error', (error) => {
      console.error('[Main] Failed to start Python:', error);
      reject(error);
    });

    pythonProcess.on('close', (code) => {
      console.log(`[Main] Python process exited with code ${code}`);
    });

    // Guard against hanging startup by timing out after 10 seconds.
    setTimeout(() => {
      reject(new Error('Python backend timeout'));
    }, 10000);
  });
}

/**
 * Instantiate the main window. Loads the UI from the frontend directory.
 */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    backgroundColor: '#1a1d24',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      sandbox: false
    },
    icon: path.join(__dirname, 'assets/icon.png')
  });

  // Load the frontend index.html file from the packaged UI.
  mainWindow.loadFile(path.join(__dirname, 'frontend/index.html'));

  if (isDev) {
    // Automatically open DevTools in development mode.
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC Handlers for communication between renderer and main processes.
ipcMain.handle('check-python-backend', async () => {
  try {
    const response = await fetch('http://127.0.0.1:8000/health');
    return response.ok;
  } catch (error) {
    return false;
  }
});

ipcMain.handle('get-models-path', () => {
  return path.join(app.getPath('userData'), 'models');
});

ipcMain.handle('check-model-updates', async () => {
  const { checkModelUpdates } = require('./scripts/check-updates.js');
  return await checkModelUpdates();
});

ipcMain.handle('download-model', async (event, modelName) => {
  const { downloadModel } = require('./scripts/download-models.js');
  return await downloadModel(modelName, (progress) => {
    event.sender.send('download-progress', { modelName, progress });
  });
});

ipcMain.handle('show-dialog', async (event, options) => {
  return await dialog.showMessageBox(mainWindow, options);
});

// Application lifecycle events.
app.whenReady().then(async () => {
  console.log('[Main] App ready, starting...');
  try {
    await startPythonBackend();
    createWindow();
  } catch (error) {
    console.error('[Main] Startup error:', error);
    dialog.showErrorBox(
      'Ошибка запуска',
      'Не удалось запустить Python backend. Убедитесь, что Python установлен.'
    );
    app.quit();
  }
});

// Gracefully stop Python process when quitting.
app.on('will-quit', () => {
  if (pythonProcess) {
    console.log('[Main] Stopping Python backend...');
    pythonProcess.kill();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});